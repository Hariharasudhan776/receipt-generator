# Receipt Generator

Generate GPay receipts (PNG) and Vendor receipts (PDF) for Vi Mobile and ACT Fibernet.

## Files in this repo

```
app.py                              ← Flask backend
index.html                          ← Frontend UI
requirements.txt                    ← Python dependencies
Procfile                            ← Render start command
Mobile_recharge_Vendor_Receipt.pdf  ← Vi template (required)
Wifi_recharge_Vendor_receipt.pdf    ← ACT template (required)
```

## Deploy to Render (Free) — 5 minutes

### Step 1 — Create GitHub repo
1. Go to https://github.com/new
2. Name it `receipt-generator`
3. Make it **Private** (recommended)
4. Click **Create repository**

### Step 2 — Upload all files
1. Click **uploading an existing file** on the new repo page
2. Drag and drop ALL files from this folder
3. Click **Commit changes**

### Step 3 — Deploy on Render
1. Go to https://render.com → Sign up free
2. Click **New** → **Web Service**
3. Connect your GitHub account → select `receipt-generator`
4. Fill in:
   - **Name**: receipt-generator
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --timeout 120`
5. Click **Create Web Service**
6. Wait ~2 minutes → you get a URL like `https://receipt-generator.onrender.com`

### Done! Share that URL with anyone.

## Run locally

```bash
pip install flask pikepdf gunicorn
python app.py
# Open http://localhost:5000
```
